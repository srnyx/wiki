# Player Shops

{% hint style="danger" %}
The player shop plugin is considered a bit unstable. Please be cautious and report any bugs [here](https://trello.com/c/L8wF1AJR/4). If you lose any items from it, we can't recover them.
{% endhint %}



