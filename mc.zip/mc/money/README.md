# Money

## How to get money

* Killing mobs
* Killing players
* Mining
* Fishing
* Completing achievements

## Where to spend money

* **`/shop`**
  * `/vehicleshop`
  * `/pshop`\(player shops\)
* **Lands/Nations**
  * Creating a Land/Nation
  * Claiming chunks
  * Paying upkeep/taxes

{% hint style="warning" %}
If you find a bug regarding the economy, please report it immediately [here](https://trello.com/c/L8wF1AJR/4).
{% endhint %}

