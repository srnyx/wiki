---
description: This page will tell you ways you can efficiently get around the world.
---

# How to get around

* Walking/running
* Boats
* `/wild` \(or `/tpr`\)
* Elytra
* Nether portals
* Vehicles

{% hint style="danger" %}
`/wild` and `/tpr` will teleport you to a random place, use at your own risk.
{% endhint %}

