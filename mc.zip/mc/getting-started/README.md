# Getting Started

{% page-ref page="getting-around.md" %}

## Wiki Pages for srnyx's MC Server

{% page-ref page="../money/" %}

{% page-ref page="../lands/" %}

{% page-ref page="../vehicles/" %}

{% page-ref page="../enchants.md" %}

{% hint style="info" %}
Join [the Discord](https://srnyx.xyz/discord) if you have any questions!
{% endhint %}



