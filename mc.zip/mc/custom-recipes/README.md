# Custom Recipes

Currently, there is only one custom recipe:

![1 Coal = 1 Black Dye](../../.gitbook/assets/coal_blackdye.png)

{% hint style="success" %}
If you have any suggestions for a custom recipe, please make a suggestion in \#mc-suggestions in the [Discord](https://mc.srnyx.xyz/discord)
{% endhint %}



