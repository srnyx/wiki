# Enchants

Custom enchants
Get to menu by doing /ce
Enchants and info
  * Sword enchants
    * Trap 1-2: Has chance to give your enemy slowness
    * Rage 1-3: Attacks will get stronger the more you keep fighting
    * Viper 1-3: has a chance to give your enemy poison
    * Snare 1-3: Has chance to give your enemy slowness and mining fatigue
    * Wither 1-3: Has a chance to give your enemy high wither
    * Vampire 1-5: Has a chance to heal you when fighting
    * Execute 1-5: Has a chance to give you strength when your enemy is low on health
    * Fast Turn 1-3: Has a chance to deal more damage
    * Paralyze 1-3: Has a chance to give your enemy high mining fatigue and slowness
    * Life Steal 1-5: Has a chance to steal health from your enemy
    * Nutrition 1-3: Has a chance to feed you while fighting
    * Oblitirate 1-3: Has a chance to send your enemy flying backwards
    * Inquisitive 1-5: Has a chance to double or more XP based on enchanment level
    * Lightweight 1-3: Has a chance to give you haste when fighting
    * Double Damage 1-3: Has a chance to do double damage
    * Famished 1-3: During combat it has a 10% (+5% per level) chance to give your enemy hunger
    
  * Axe Enchants
    * Rekt 1-3: Has a chance to deal double damage
    * FeedMe 1-5: Has a chance to feed you while fighting
    * Berserk 1-3: Has a chance to give you stength and mining fatuigue
    * Blessed 1-3: Has a chance to remove all negative effects
    * BattleCry 1-5: During combat it has a 10% (+5% per level) chance to send your enemy flying backwards
    
    add more later
